
read tutorial for fetch and python-requests for further stuff....

explore this tesing apis for practice.

https://jsonplaceholder.typicode.com/
